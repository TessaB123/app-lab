angular.module('ionicApp.controllers', [])

    .controller('MainCtrl', function($scope, $state, $ionicSideMenuDelegate) {
        //console.log('MainCtrl');
        //setTimeout(function () {
        //    navigator.splashscreen.hide();
        //}, 750);

        $scope.toggleLeft = function() {
            $ionicSideMenuDelegate.toggleLeft();
        };

        $scope.toIntro = function() {
            window.localStorage['didTutorial'] = "false";
            $state.go('app.intro');
        };
    })

    .controller('ProfielCtrl', function($scope) {

    })

    .controller('PlanningCtrl', function($scope) {

    })

    .controller('IntroCtrl', function($scope, $state, $ionicSlideBoxDelegate) {
        $scope.startApp = function () {
            $state.go('app.home');
        };

        $scope.next = function(){
            $ionicSlideBoxDelegate.next();
        };

        $scope.previous = function () {
            $ionicSlideBoxDelegate.previous();
        };
    });